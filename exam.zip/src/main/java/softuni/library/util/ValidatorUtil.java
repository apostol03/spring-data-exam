package softuni.library.util;

public interface ValidatorUtil {
    <T> boolean isValid(T entity);
}
